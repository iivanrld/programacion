<?php
//Ejercicio 4: Uso de For
//Crea un programa que imprima los números del 1 al 10 en una línea usando un bucle for.
function salta(){
    echo PHP_EOL;
}

for ($n = 1; $n <= 10; $n++) {
    echo $n . " ";
}
?>